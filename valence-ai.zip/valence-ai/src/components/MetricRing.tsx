"use client";
import { RadialBarChart, RadialBar, PolarAngleAxis } from 'recharts';

interface MetricRingProps {
  /** Percentage value between 0 and 100. */
  value: number;
  /** Name of the metric (displayed beneath the ring). */
  label: string;
  /** Optional colour of the ring. */
  color?: string;
}

/**
 * MetricRing renders a circular progress indicator for a given metric using
 * Recharts.  It accepts a numeric value (0–100) and displays the name
 * beneath the ring.  If no colour is provided, the accent colour from
 * your Tailwind config is used.
 */
export default function MetricRing({ value, label, color = '#6366f1' }: MetricRingProps) {
  const data = [
    {
      name: label,
      value,
      fill: color,
    },
  ];
  return (
    <div className="flex flex-col items-center justify-center">
      <RadialBarChart
        width={120}
        height={120}
        cx="50%"
        cy="50%"
        innerRadius="70%"
        outerRadius="100%"
        data={data}
        startAngle={90}
        endAngle={-270}
      >
        <PolarAngleAxis
          type="number"
          domain={[0, 100]}
          dataKey="value"
          tick={false}
        />
        <RadialBar
          background
          dataKey="value"
          cornerRadius={50}
        />
      </RadialBarChart>
      <span className="mt-2 text-sm text-gray-300">{label}</span>
    </div>
  );
}