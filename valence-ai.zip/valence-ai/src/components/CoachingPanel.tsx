interface CoachingInsight {
  text: string;
  tags?: string;
}

interface CoachingPanelProps {
  insights: CoachingInsight[];
}

/**
 * CoachingPanel lists personalised insights.  It accepts an array of
 * insights and renders them in a card.  If no insights are passed, the
 * component returns null.
 */
export default function CoachingPanel({ insights }: CoachingPanelProps) {
  if (!insights || insights.length === 0) {
    return null;
  }
  return (
    <div className="p-4 bg-card rounded-lg">
      <h2 className="font-semibold text-lg mb-2">Coaching Insights</h2>
      <ul className="space-y-2 text-sm text-gray-300">
        {insights.map((insight, idx) => (
          <li key={idx}>{insight.text}</li>
        ))}
      </ul>
    </div>
  );
}