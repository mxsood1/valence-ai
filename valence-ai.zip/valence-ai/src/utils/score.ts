/**
 * Utility functions for calculating derived scores from raw metrics.  These
 * functions are kept deliberately simple for demonstration purposes and are
 * covered by unit tests in the `__tests__` directory.
 */

export function calculateRecoveryScore(hrv: number, rhr: number): number {
  // A naive recovery score: higher HRV and lower RHR yields a better score.
  const normalizedHrv = Math.min(Math.max((hrv - 40) / 40, 0), 1);
  const normalizedRhr = 1 - Math.min(Math.max((rhr - 40) / 40, 0), 1);
  return Math.round((normalizedHrv * 0.6 + normalizedRhr * 0.4) * 100);
}

export function calculateStrainScore(steps: number, calories: number): number {
  // Simple algorithm: more steps and calories burned increases strain score.
  const stepScore = Math.min(steps / 10000, 1);
  const calorieScore = Math.min(calories / 3000, 1);
  return Math.round((stepScore * 0.7 + calorieScore * 0.3) * 100);
}