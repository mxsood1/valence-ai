/**
 * A simple rules engine that produces coaching text based on the latest metrics.
 * If you provide an OPENAI_API_KEY in your environment, the `generateAIInsights`
 * function can call OpenAI to produce richer recommendations. Otherwise, the
 * rules engine below is used.
 */

export function generateCoaching(metrics: { sleepScore?: number; strainScore?: number; calories?: number; steps?: number; }): string[] {
  const insights: string[] = [];
  if (typeof metrics.sleepScore === 'number' && metrics.sleepScore < 70) {
    insights.push('Your sleep score is below optimal. Try to go to bed earlier and avoid screens before bed.');
  }
  if (typeof metrics.strainScore === 'number' && metrics.strainScore > 80) {
    insights.push('High strain today. Schedule some recovery time tomorrow.');
  }
  if (typeof metrics.calories === 'number' && metrics.calories > 2500) {
    insights.push('Calorie intake is higher than average. Focus on nutrient‑dense foods and portion sizes.');
  }
  if (typeof metrics.steps === 'number' && metrics.steps < 5000) {
    insights.push('You have not reached 5k steps today. A short walk can help increase your activity.');
  }
  if (insights.length === 0) {
    insights.push('Keep up the great work! Your metrics are in a healthy range.');
  }
  return insights;
}

// Example of optional OpenAI integration. This function is not called by
// default; if you wish to use it, ensure you set OPENAI_API_KEY in your env.
export async function generateAIInsights(prompt: string): Promise<string> {
  if (!process.env.OPENAI_API_KEY) {
    return '';
  }
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 120,
    }),
  });
  const data = await response.json();
  return data.choices?.[0]?.message?.content ?? '';
}