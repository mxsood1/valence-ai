import { prisma } from '@/lib/prisma';
import { authOptions } from '../api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth';

/**
 * Settings page allows users to update profile, goals, integrations and privacy
 * preferences.  This MVP only displays basic information for the demo
 * account.  In future iterations this could include forms to update data
 * and manage connected providers.
 */
export default async function SettingsPage() {
  const session = await getServerSession(authOptions);
  const email = session?.user?.email ?? 'demo@valence.ai';
  const user = await prisma.user.findFirst({ where: { email } });
  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Settings</h1>
      <div className="bg-card p-4 rounded">
        <h2 className="font-semibold mb-2">Profile</h2>
        <p className="text-sm text-gray-400">Name: {user?.name ?? 'Demo User'}</p>
        <p className="text-sm text-gray-400">Email: {user?.email}</p>
      </div>
      <div className="bg-card p-4 rounded">
        <h2 className="font-semibold mb-2">Integrations</h2>
        <p className="text-sm text-gray-400">Apple Health, Fitbit, Garmin, Oura and Whoop integrations will be available soon.</p>
      </div>
      <div className="bg-card p-4 rounded">
        <h2 className="font-semibold mb-2">Goals & Privacy</h2>
        <p className="text-sm text-gray-400">This section will let you configure daily goals, reminders and privacy preferences.</p>
      </div>
    </div>
  );
}