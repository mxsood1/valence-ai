"use client";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const data = [
  { day: 'Mon', stress: 40 },
  { day: 'Tue', stress: 55 },
  { day: 'Wed', stress: 35 },
  { day: 'Thu', stress: 60 },
  { day: 'Fri', stress: 50 },
  { day: 'Sat', stress: 30 },
  { day: 'Sun', stress: 45 },
];

export default function StressPage() {
  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Stress</h1>
      <p className="text-sm text-gray-400">Your stress levels over the past week.</p>
      <div className="w-full h-64 bg-card rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="day" stroke="#888" />
            <YAxis stroke="#888" domain={[0, 100]} />
            <Tooltip />
            <Line type="monotone" dataKey="stress" stroke="#ef4444" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}