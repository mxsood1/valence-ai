"use client";
import { signIn } from 'next-auth/react';
import { useState } from 'react';
import Link from 'next/link';

export default function SignInPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const res = await signIn('credentials', {
        redirect: false,
        email,
        password,
      });
      if (res?.error) {
        setError(res.error);
      } else {
        window.location.href = '/dashboard';
      }
    } catch (err: any) {
      setError('Failed to sign in');
    }
  }
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <h1 className="text-2xl font-bold mb-6">Sign in to Valence AI</h1>
      <form onSubmit={handleSubmit} className="w-full max-w-sm bg-card p-6 rounded-lg space-y-4">
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <div>
          <label className="block text-sm mb-1" htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2 rounded bg-background border border-gray-700"
            required
          />
        </div>
        <div>
          <label className="block text-sm mb-1" htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-3 py-2 rounded bg-background border border-gray-700"
            required
          />
        </div>
        <button type="submit" className="w-full bg-accent text-white py-2 rounded hover:bg-indigo-500">
          Sign In
        </button>
        <p className="text-xs text-center">
          Use the demo account (`demo@valence.ai`) without a password or create an account via GitHub.
        </p>
        <button
          type="button"
          onClick={() => signIn('github')}
          className="w-full mt-2 border border-accent text-accent py-2 rounded hover:bg-card"
        >
          Sign in with GitHub
        </button>
        <div className="text-center mt-2">
          <Link href="/">← Back to home</Link>
        </div>
      </form>
    </div>
  );
}