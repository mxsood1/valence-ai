"use client";
import { useEffect, useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface DataPoint {
  date: string;
  score: number;
}

const initialData: DataPoint[] = [
  { date: 'Mon', score: 75 },
  { date: 'Tue', score: 72 },
  { date: 'Wed', score: 78 },
  { date: 'Thu', score: 70 },
  { date: 'Fri', score: 74 },
  { date: 'Sat', score: 80 },
  { date: 'Sun', score: 77 },
];

export default function SleepPage() {
  const [data, setData] = useState<DataPoint[]>(initialData);

  // In a real app you'd fetch sleep metrics from the API on mount.
  useEffect(() => {
    // placeholder for fetching data
  }, []);

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Sleep</h1>
      <p className="text-sm text-gray-400">Your sleep score over the past week.</p>
      <div className="w-full h-64 bg-card rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="date" stroke="#888" />
            <YAxis stroke="#888" domain={[0, 100]} />
            <Tooltip />
            <Line type="monotone" dataKey="score" stroke="#6366f1" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}