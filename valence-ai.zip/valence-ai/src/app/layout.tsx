import '@/styles/globals.css';
import { ReactNode } from 'react';

export const metadata = {
  title: 'Valence AI – All‑in‑one health hub',
  description: 'Unified dashboard for your wellness data',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-background text-gray-200 font-sans">
        {children}
      </body>
    </html>
  );
}