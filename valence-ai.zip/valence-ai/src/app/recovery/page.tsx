"use client";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const data = [
  { day: 'Mon', recovery: 60 },
  { day: 'Tue', recovery: 58 },
  { day: 'Wed', recovery: 65 },
  { day: 'Thu', recovery: 55 },
  { day: 'Fri', recovery: 70 },
  { day: 'Sat', recovery: 68 },
  { day: 'Sun', recovery: 72 },
];

export default function RecoveryPage() {
  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Recovery</h1>
      <p className="text-sm text-gray-400">Your recovery score over the past week.</p>
      <div className="w-full h-64 bg-card rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="day" stroke="#888" />
            <YAxis stroke="#888" domain={[0, 100]} />
            <Tooltip />
            <Bar dataKey="recovery" fill="#10b981" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}