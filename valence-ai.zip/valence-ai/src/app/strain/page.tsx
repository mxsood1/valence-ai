"use client";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const data = [
  { day: 'Mon', strain: 50 },
  { day: 'Tue', strain: 65 },
  { day: 'Wed', strain: 60 },
  { day: 'Thu', strain: 75 },
  { day: 'Fri', strain: 55 },
  { day: 'Sat', strain: 80 },
  { day: 'Sun', strain: 70 },
];

export default function StrainPage() {
  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Strain</h1>
      <p className="text-sm text-gray-400">Your activity load over the past week.</p>
      <div className="w-full h-64 bg-card rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorStrain" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="day" stroke="#888" />
            <YAxis stroke="#888" domain={[0, 100]} />
            <Tooltip />
            <Area type="monotone" dataKey="strain" stroke="#f59e0b" fillOpacity={1} fill="url(#colorStrain)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}