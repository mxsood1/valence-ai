import { prisma } from '@/lib/prisma';
import Link from 'next/link';

/**
 * A simple habits dashboard that lists habits and streaks.  In a real app
 * this would allow the user to mark habits as complete and track their
 * progress over time.
 */
export default async function HabitsPage() {
  const demoUser = await prisma.user.findFirst({ where: { email: 'demo@valence.ai' } });
  const habits = await prisma.habit.findMany({
    where: { userId: demoUser?.id },
    include: { logs: true },
  });
  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Habits</h1>
      {habits.length === 0 && <p className="text-sm text-gray-400">No habits found. Start by creating one in your settings.</p>}
      <ul className="space-y-2">
        {habits.map((habit) => (
          <li key={habit.id} className="bg-card p-3 rounded flex justify-between items-center">
            <span>{habit.name}</span>
            <span className="text-sm text-gray-500">Streak: {habit.streak} days</span>
          </li>
        ))}
      </ul>
      <p className="text-xs text-gray-500">Habit tracking and goals management will be expanded in future versions.</p>
    </div>
  );
}