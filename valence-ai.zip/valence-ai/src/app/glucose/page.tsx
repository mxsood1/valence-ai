"use client";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const data = [
  { time: '08:00', glucose: 90 },
  { time: '10:00', glucose: 110 },
  { time: '12:00', glucose: 130 },
  { time: '14:00', glucose: 105 },
  { time: '16:00', glucose: 95 },
  { time: '18:00', glucose: 125 },
  { time: '20:00', glucose: 115 },
];

export default function GlucosePage() {
  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Glucose</h1>
      <p className="text-sm text-gray-400">Glucose levels throughout the day.</p>
      <div className="w-full h-64 bg-card rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="time" stroke="#888" />
            <YAxis stroke="#888" domain={[80, 140]} />
            <Tooltip />
            <Line type="monotone" dataKey="glucose" stroke="#f43f5e" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}