import { prisma } from '@/lib/prisma';
import MetricRing from '@/components/MetricRing';
import CoachingPanel from '@/components/CoachingPanel';
import { generateCoaching } from '@/lib/ai';

/**
 * The Dashboard page fetches the latest metrics for the signed‑in user and
 * displays them using circular widgets.  It also shows a simple coaching
 * panel powered by a rules engine.  In a real deployment the session
 * information from NextAuth would be used to scope the query; in this
 * example we fall back to the demo account.
 */
export default async function DashboardPage() {
  // Fallback to the demo user when no session is present.  In a real
  // application you would use getServerSession from `next-auth` to retrieve
  // the logged in user.
  const demoUser = await prisma.user.findFirst({ where: { email: 'demo@valence.ai' } });
  const metric = await prisma.wearableMetric.findFirst({
    where: { userId: demoUser?.id },
    orderBy: { timestamp: 'desc' },
  });

  const metricsValues = {
    sleepScore: metric?.sleepScore ?? 0,
    strainScore: metric?.strainScore ?? 0,
    calories: metric?.calories ?? 0,
    steps: metric?.steps ?? 0,
  };
  const coachingTexts = generateCoaching(metricsValues);
  const insights = coachingTexts.map((text) => ({ text }));

  return (
    <div className="p-4 space-y-8">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricRing value={metricsValues.strainScore} label="Strain" />
        <MetricRing value={metricsValues.sleepScore} label="Sleep" />
        <MetricRing value={metricsValues.steps ? Math.min(Math.round((metricsValues.steps / 10000) * 100), 100) : 0} label="Steps" />
        <MetricRing value={metricsValues.calories ? Math.min(Math.round((metricsValues.calories / 3000) * 100), 100) : 0} label="Calories" />
      </div>
      <CoachingPanel insights={insights} />
    </div>
  );
}