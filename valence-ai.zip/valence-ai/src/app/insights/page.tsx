import { prisma } from '@/lib/prisma';

/**
 * The Insights page presents a feed of coaching insights generated for the
 * user.  In the MVP this simply lists the latest entries in the
 * `CoachingInsight` table.  Future versions could allow commenting,
 * feedback and more sophisticated AI generation.
 */
export default async function InsightsPage() {
  const demoUser = await prisma.user.findFirst({ where: { email: 'demo@valence.ai' } });
  const insights = await prisma.coachingInsight.findMany({
    where: { userId: demoUser?.id },
    orderBy: { createdAt: 'desc' },
    take: 10,
  });
  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Insights</h1>
      {insights.length === 0 && <p className="text-sm text-gray-400">No insights yet. As you record more data, personalised coaching will appear here.</p>}
      <ul className="space-y-2">
        {insights.map((insight) => (
          <li key={insight.id} className="bg-card p-3 rounded text-sm text-gray-300">
            {insight.text}
          </li>
        ))}
      </ul>
    </div>
  );
}