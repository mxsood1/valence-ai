import Link from 'next/link';

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen px-4 py-8 text-center">
      <h1 className="text-4xl md:text-6xl font-bold mb-4">Valence AI</h1>
      <p className="text-lg mb-8 max-w-2xl">
        All‑in‑one health hub. Unite your wearables and wellness data in a single elegant dashboard.
      </p>
      <div className="flex space-x-4 mb-12">
        <Link
          href="/dashboard"
          className="px-6 py-3 bg-accent rounded-lg text-white font-semibold hover:bg-indigo-500"
        >
          Open Dashboard
        </Link>
        <Link
          href="/auth/signin"
          className="px-6 py-3 border border-accent rounded-lg text-accent font-semibold hover:bg-card"
        >
          Sign In
        </Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-4xl">
        {['Sleep','Fitness','Nutrition','Stress','Recovery','Habits','Glucose','Coaching'].map((item) => (
          <div key={item} className="p-4 bg-card rounded-lg text-sm font-medium">
            {item}
          </div>
        ))}
      </div>
    </main>
  );
}