"use client";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

const data = [
  { name: 'Protein', value: 80 },
  { name: 'Carbs', value: 150 },
  { name: 'Fat', value: 60 },
];

const COLORS = ['#6366f1', '#3b82f6', '#8b5cf6'];

export default function NutritionPage() {
  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Nutrition</h1>
      <p className="text-sm text-gray-400">Daily macro distribution.</p>
      <div className="w-full h-64 bg-card rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={40}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              label
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}