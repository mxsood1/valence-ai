# Valence AI

Valence AI is a modern, all‑in‑one health hub.  It unifies your wearable and lifestyle data into a single, elegant dashboard so you can track **Strain**, **Recovery**, **Sleep**, **Nutrition**, **Stress**, **Energy**, **Habits**, **Glucose** and more.  It also delivers personalised coaching insights based on your recent metrics.

## Features

* **Next.js App Router** – built with the latest Next.js architecture using server components.
* **TypeScript & TailwindCSS** – a type‑safe codebase with a dark, premium UI theme.
* **shadcn/ui & lucide-react** – reusable components and beautiful icons.
* **Prisma & PostgreSQL** – robust data modelling with a Postgres database and ORM.
* **NextAuth** – sign in with email/password or GitHub OAuth; fully protected routes.
* **Zod** – runtime validation for your forms and API routes.
* **Recharts** – interactive charts for trends and historical data.
* **Seed & Demo Mode** – realistic seed data so new accounts immediately see populated dashboards.
* **AI Coaching Engine** – a simple rules engine with optional OpenAI integration for smart insights.
* **Docker** – a dockerised database for local development.
* **GitHub Actions** – CI checks for linting, type‑checking and tests.

## Getting started

1. **Clone the repository**

   ```bash
   git clone https://github.com/mxsood1/valence-ai.git
   cd valence-ai
   ```

2. **Install dependencies**

   Ensure you have Node 16+ and pnpm or npm installed.  Then run:

   ```bash
   npm install
   # or
   pnpm install
   ```

3. **Configure your environment**

   Copy `.env.example` to `.env` and fill in the missing values.  At minimum you need to set:

   * `DATABASE_URL` – your Postgres connection string.
   * `NEXTAUTH_SECRET` – a random string used to sign JWTs.
   * `NEXTAUTH_URL` – the URL where your app will be served during development.
   * Optional: `GITHUB_ID`/`GITHUB_SECRET` for GitHub OAuth, and `OPENAI_API_KEY` for AI‑generated coaching.

4. **Run the database**

   A `docker-compose.yml` is provided for local development.  Start Postgres via Docker:

   ```bash
   docker compose up -d
   ```

   This will create a `valence` database with a `postgres` user and password.

5. **Run migrations and seed**

   Generate the Prisma client, run migrations and seed the database:

   ```bash
   npx prisma migrate deploy
   npm run seed
   ```

6. **Start the development server**

   ```bash
   npm run dev
   ```

   The app will be available at `http://localhost:3000`.

7. **Log in**

   Use the **demo account** seeded by the script (`demo@valence.ai` with no password) or create a new account via the sign‑up flow.  Once logged in, your dashboard will display example metrics, charts, tags and coaching suggestions.

## Project structure

```
valence-ai/
├── prisma/               # Prisma schema and seed script
├── src/
│   ├── app/             # App router pages and layouts
│   ├── components/      # Reusable UI components (charts, rings, panels)
│   ├── lib/             # Helpers (Prisma client, AI logic)
│   ├── styles/          # Global styles
│   └── utils/           # Utility functions and types
├── .github/workflows/    # Continuous integration pipeline
├── docker-compose.yml    # Local Postgres service
├── package.json          # NPM scripts and dependencies
└── README.md
```

## Screenshots

<p align="center">
  <img src="./.github/screenshot-dashboard.png" alt="Dashboard screenshot" width="700" />
</p>

<!--
You can capture your own screenshots by running the app locally.  Place them in `.github` and reference them above.
-->

## Contributing

Contributions are welcome!  Feel free to fork the project and open pull requests.  Please avoid using placeholder copy (no lorem ipsum) – everything in the UI should feel like a real, premium health application.

## License

This project is provided for educational and demonstration purposes.  See the `LICENSE` file for details.