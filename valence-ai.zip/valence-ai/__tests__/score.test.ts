import { calculateRecoveryScore, calculateStrainScore } from '../src/utils/score';

describe('score utilities', () => {
  test('calculateRecoveryScore returns 100 for ideal values', () => {
    expect(calculateRecoveryScore(80, 40)).toBe(100);
  });

  test('calculateRecoveryScore returns lower score for low HRV and high RHR', () => {
    const score = calculateRecoveryScore(50, 70);
    expect(score).toBeLessThan(50);
  });

  test('calculateStrainScore returns 100 for high steps and calories', () => {
    expect(calculateStrainScore(20000, 6000)).toBe(100);
  });

  test('calculateStrainScore scales with input', () => {
    const low = calculateStrainScore(2000, 500);
    const high = calculateStrainScore(10000, 3000);
    expect(low).toBeLessThan(high);
  });
});