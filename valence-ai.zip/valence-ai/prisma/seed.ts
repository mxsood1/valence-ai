import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Upsert a demo user for previewing the dashboard
  const user = await prisma.user.upsert({
    where: { email: 'demo@valence.ai' },
    update: {},
    create: {
      email: 'demo@valence.ai',
      name: 'Demo User',
      passwordHash: null,
    },
  });

  const now = new Date();
  // Remove existing metrics for this user before reseeding
  await prisma.wearableMetric.deleteMany({ where: { userId: user.id } });
  // Seed a month of metrics
  for (let i = 0; i < 30; i++) {
    const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    await prisma.wearableMetric.create({
      data: {
        userId: user.id,
        timestamp: date,
        hrv: 60 + Math.floor(Math.random() * 20),
        rhr: 50 + Math.floor(Math.random() * 10),
        sleepScore: 70 + Math.floor(Math.random() * 10),
        strainScore: 60 + Math.floor(Math.random() * 20),
        steps: 5000 + Math.floor(Math.random() * 5000),
        calories: 2000 + Math.floor(Math.random() * 500),
      },
    });
  }
  console.log('Database has been seeded with demo data');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });